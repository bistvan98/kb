﻿  using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KBSzamlalo
{
    public static class Settings
    {
        public static bool SoundOn { get; set; } = false;
        public static bool StopWatch { get; set; } = false;
    }
}
