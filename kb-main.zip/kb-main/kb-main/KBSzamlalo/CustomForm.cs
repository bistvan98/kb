﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Xml.Linq;

namespace KBSzamlalo
{
    public partial class CustomForm : Form
    {
        private int Rows = 0;
        private bool IsWork = false;
        private bool FinishedAdding = true;

        Point pos1 = new Point(50, 325);
        Point pos2 = new Point(75, 325);
        Point pos3 = new Point(135, 325);
        Point pos4 = new Point(175, 325);

        public CustomForm()
        {
            Settings.LineCounter = 0;
            InitializeComponent();
            LoadDefault();
            rowCounterLabel.Text = "0";
        }

        private void xPictureBox_Click(object sender, EventArgs e)
        {
            if (Settings.InterVall)
            {
                xPictureBox.Image = KBSzamlalo.Properties.Resources.black;
                Settings.InterVall = false;
                LoadDefault();
            }
            else
            {
                xPictureBox.Image = KBSzamlalo.Properties.Resources.x;
                Settings.InterVall = true;
                LoadIntervall();
            }
        }

        private void plusWorkButton_Click(object sender, EventArgs e)
        {
            if (FinishedAdding)
            {
                FinishedAdding = false;
                Settings.LineCounter++;
            }

            IsWork = true;
            testMinTextBox.Text = "0";
            testSecTextBox.Text = "0";
            testMinTextBox.Show();
            testSecTextBox.Show();
            addNewButton.Show();
            addNewLabel.Text = "Add new work: ";
            addNewLabel.Show();
            dotsLabel.Show();
            cancelButton.Show();
        }

        private void plusRestButton_Click(object sender, EventArgs e)
        {
            if (FinishedAdding)
            {
                FinishedAdding = false;
                Settings.LineCounter++;
            }

            IsWork = false;
            testMinTextBox.Text = "0";
            testSecTextBox.Text = "0";
            testMinTextBox.Show();
            testSecTextBox.Show();
            addNewButton.Show();
            addNewLabel.Text = "Add new rest: ";
            addNewLabel.Show();
            dotsLabel.Show();
            cancelButton.Show();
        }

        private void SortLines()
        {
            string Name1, Name2;

            for (int i = 1; i < 4; i++)
            {
                Name1 = "id" + i + "Label";
                Name2 = "id" + (i + 1) + "Label";
                Label lb1 = (Label)this.Controls[Name1];
                Label lb2 = (Label)this.Controls[Name2];
                lb1.Text = lb2.Text;

                Name1 = "typeLabel" + i;
                Name2 = "typeLabel" + (i + 1);
                lb1 = (Label)this.Controls[Name1];
                lb2 = (Label)this.Controls[Name2];
                lb1.Text = lb2.Text;
                lb1.ForeColor = lb2.ForeColor;

                Name1 = "time" + i + "Label";
                Name2 = "time" + (i + 1) + "Label";
                lb1 = (Label)this.Controls[Name1];
                lb2 = (Label)this.Controls[Name2];
                lb1.Text = lb2.Text;
            }

            bottomLineLabel.Hide();
            topLineLabel.Show();
        }

        private void remove1_Click(object sender, EventArgs e)
        {
            if (FinishedAdding)
            {
                RemoveLine(1);
                Settings.LineCounter--;
            }
            else
            {
                MessageBox.Show("Can't remove the line while you're adding a new one!");
            }
        }

        private void remove2_Click(object sender, EventArgs e)
        {
            if (FinishedAdding)
            {
                RemoveLine(2);
                Settings.LineCounter--;
            }
            else
            {
                MessageBox.Show("Can't remove the line while you're adding a new one!");
            }
        }

        private void remove3_Click(object sender, EventArgs e)
        {
            if (FinishedAdding)
            {
                RemoveLine(3);
                Settings.LineCounter--;
            }
            else
            {
                MessageBox.Show("Can't remove the line while you're adding a new one!");
            }
        }

        private void remove4_Click(object sender, EventArgs e)
        {
            if (FinishedAdding)
            {
                RemoveLine(4);
                Settings.LineCounter--;
            }
            else
            {
                MessageBox.Show("Can't remove the line while you're adding a new one!");
            }
        }

        private void ClearRow(int LineID)
        {
            string name = "id" + LineID + "Label";
            Label lb = (Label)this.Controls[name];
            lb.Text = LineID.ToString();
            lb.Hide();

            name = "typeLabel" + LineID;
            lb = (Label)this.Controls[name];
            lb.Hide();

            name = "time" + LineID + "Label";
            lb = (Label)this.Controls[name];
            lb.Hide();

            name = "upArrow" + LineID;
            PictureBox pb = (PictureBox)this.Controls[name];
            pb.Hide();

            name = "downArrow" + LineID;
            pb = (PictureBox)this.Controls[name];
            pb.Hide();

            name = "duplicate" + LineID;
            pb = (PictureBox)this.Controls[name];
            pb.Hide();

            name = "remove" + LineID;
            pb = (PictureBox)this.Controls[name];
            pb.Hide();

        }

        private void RemoveFirst()
        {
            int ElementID;

            if (Settings.LineCounter == 1)
            {
                ClearRow(1);
                SortList(0, 1);
            }
            else
            {
                int MaxLine;
                if (Settings.LineCounter <= 4)
                {
                    MaxLine = Settings.LineCounter;
                }
                else
                {
                    MaxLine = 4;
                }

                Label lb1 = (Label)this.Controls["id1Label"];
                int RowsFront = Settings.LineCounter - Convert.ToInt32(lb1.Text);
                ElementID = Convert.ToInt32(lb1.Text);

                string name1, name2;
                for (int i = 1; i < MaxLine; i++)
                {
                    name1 = "typeLabel" + i;
                    name2 = "typeLabel" + (i + 1);
                    lb1 = (Label)this.Controls[name1];
                    Label lb2 = (Label)this.Controls[name2];
                    lb1.Text = lb2.Text;
                    lb1.ForeColor = lb2.ForeColor;

                    name1 = "time" + i + "Label";
                    name2 = "time" + (i + 1) + "Label";
                    lb1 = (Label)this.Controls[name1];
                    lb2 = (Label)this.Controls[name2];
                    lb1.Text = lb2.Text;
                }

                if (Settings.LineCounter <= 4)
                {
                    ClearRow(Settings.LineCounter);
                }
                else
                {
                    if (Settings.LineCounter - ElementID >= 4)
                    {
                        int ListIndex = (ElementID + 1) * 3;

                        lb1 = (Label)this.Controls["typeLabel4"];
                        lb1.Text = Settings.Lines[ListIndex + 1];

                        if (lb1.Text == "work")
                        {
                            lb1.ForeColor = Color.White;
                        }
                        else
                        {
                            lb1.ForeColor = Color.Red;
                        }

                        lb1 = (Label)this.Controls["time4Label"];
                        lb1.Text = Settings.Lines[ListIndex + 2];
                    }
                    else
                    {
                        Label lb = (Label)this.Controls["id1Label"];
                        if (Convert.ToInt32(lb.Text) != 1)
                        {
                            MoveList(1);
                        }
                    }
                }

                SortList(Settings.LineCounter - ElementID, 1);
            }
        }

        private void RemoveMidLines(int LineId)
        {
            if (Settings.LineCounter == LineId)
            {
                ClearRow(LineId);
                SortList(0, LineId);
            }
            else
            {
                string name1 = "id" + LineId + "Label";
                Label lb1 = (Label)this.Controls[name1];
                int ItemId = Convert.ToInt32(lb1.Text);

                string name2;

                if (Settings.LineCounter > 4)
                {
                    if (Settings.LineCounter - LineId >= 5 - LineId)
                    {
                        for (int i = LineId; i < 4; i++)
                        {
                            name1 = "typeLabel" + i;
                            name2 = "typeLabel" + (i + 1);
                            lb1 = (Label)this.Controls[name1];
                            Label lb2 = (Label)this.Controls[name2];
                            lb1.Text = lb2.Text;
                            lb1.ForeColor = lb2.ForeColor;

                            name1 = "time" + i + "Label";
                            name2 = "time" + (i + 1) + "Label";
                            lb1 = (Label)this.Controls[name1];
                            lb2 = (Label)this.Controls[name2];
                            lb1.Text = lb2.Text;
                        }

                        int ListID = 0;

                        switch (LineId)
                        {
                            case 2:
                                lb1 = (Label)this.Controls["id2Label"];
                                if (Convert.ToInt32(lb1.Text) == Settings.LineCounter - 2)
                                {
                                    ListID = (ItemId * 3) - 3;
                                }
                                else
                                {
                                    ListID = ((ItemId + 3) * 3) - 3;
                                }
                                break;

                            case 3:
                                lb1 = (Label)this.Controls["id3Label"];
                                if (Convert.ToInt32(lb1.Text) == Settings.LineCounter - 1)
                                {
                                    ListID = ItemId * 3;
                                }
                                else
                                {
                                    ListID = (ItemId * 3) + 3;
                                }
                                break;
                        }

                        lb1 = (Label)this.Controls["id4Label"];
                        lb1.Text = Convert.ToString(Convert.ToInt32(Settings.Lines[ListID]) - 1);

                        lb1 = (Label)this.Controls["typeLabel4"];
                        lb1.Text = Settings.Lines[ListID + 1];

                        if (lb1.Text == "work")
                        {
                            lb1.ForeColor = Color.White;
                        }
                        else
                        {
                            lb1.ForeColor = Color.Red;
                        }

                        lb1 = (Label)this.Controls["time4Label"];
                        lb1.Text = Settings.Lines[ListID + 2];

                        lb1 = (Label)this.Controls["id1Label"];

                        if (lb1.Text != "1")
                        {
                            MoveList(1);
                        }

                        int counter = 0;
                        int ListId = ItemId * 3;
                        while (counter < 3)
                        {
                            Settings.Lines.RemoveAt(ListId - 3);
                            counter++;
                        }

                        int RowsFront = Settings.LineCounter - ItemId;

                        for (int i = 0; i < RowsFront; i++)
                        {
                            Settings.Lines[ListId - 3 + (i * 3)] = Convert.ToString(Convert.ToInt32(Settings.Lines[ListId - 3 + (i * 3)]) - 1);
                        }
                    }
                    else
                    {
                        for (int i = LineId; i < 4; i++)
                        {

                            switch (LineId)
                            {
                                case 2:
                                    name1 = "typeLabel" + i;
                                    name2 = "typeLabel" + (i + 1);
                                    lb1 = (Label)this.Controls[name1];
                                    Label lb2 = (Label)this.Controls[name2];
                                    lb1.Text = lb2.Text;
                                    lb1.ForeColor = lb2.ForeColor;

                                    name1 = "time" + i + "Label";
                                    name2 = "time" + (i + 1) + "Label";
                                    lb1 = (Label)this.Controls[name1];
                                    lb2 = (Label)this.Controls[name2];
                                    lb1.Text = lb2.Text;
                                    break;

                                case 3:
                                    name1 = "typeLabel" + i;
                                    name2 = "typeLabel" + (i - 1);
                                    lb1 = (Label)this.Controls[name1];
                                    lb2 = (Label)this.Controls[name2];
                                    lb2.Text = lb1.Text;
                                    lb2.ForeColor = lb1.ForeColor;

                                    name1 = "time" + i + "Label";
                                    name2 = "time" + (i - 1) + "Label";
                                    lb1 = (Label)this.Controls[name1];
                                    lb2 = (Label)this.Controls[name2];
                                    lb2.Text = lb1.Text;
                                    break;
                            }
                        }

                        Label lb = (Label)this.Controls["id1Label"];

                        if (Convert.ToInt32(lb.Text) != 1)
                        {
                            MoveList(1);
                        }

                        SortList(Settings.LineCounter - ItemId, LineId);
                    }
                }
                else
                {
                    for (int i = ItemId; i < ItemId + (Settings.LineCounter - ItemId); i++)
                    {
                        name1 = "typeLabel" + i;
                        name2 = "typeLabel" + (i + 1);
                        lb1 = (Label)this.Controls[name1];
                        Label lb2 = (Label)this.Controls[name2];
                        lb1.Text = lb2.Text;
                        lb1.ForeColor = lb2.ForeColor;

                        name1 = "time" + i + "Label";
                        name2 = "time" + (i + 1) + "Label";
                        lb1 = (Label)this.Controls[name1];
                        lb2 = (Label)this.Controls[name2];
                        lb1.Text = lb2.Text;
                    }

                    if (Settings.LineCounter <= 4)
                    {
                        ClearRow(Settings.LineCounter);
                    }
                    else
                    {
                        if (Settings.LineCounter - ItemId >= 5 - LineId)
                        {
                            int ListIndex = 0;

                            switch (LineId)
                            {
                                case 2:
                                    ListIndex = ((ItemId + 1) * 3) + 3;
                                    break;

                                case 3:
                                    ListIndex = (ItemId * 3) + 3;
                                    break;
                            }


                            lb1 = (Label)this.Controls["typeLabel4"];
                            lb1.Text = Settings.Lines[ListIndex + 1];

                            if (lb1.Text == "work")
                            {
                                lb1.ForeColor = Color.White;
                            }
                            else
                            {
                                lb1.ForeColor = Color.Red;
                            }

                            lb1 = (Label)this.Controls["time4Label"];
                            lb1.Text = Settings.Lines[ListIndex + 2];
                        }
                        else
                        {
                            Label lb = (Label)this.Controls["id1Label"];
                            if (Convert.ToInt32(lb.Text) != 1)
                            {
                                MoveList(1);
                            }
                        }
                    }

                    SortList(Settings.LineCounter - ItemId, LineId);
                }
            }
        }

        private void RemoveLine(int LineID)
        {
            switch (LineID)
            {
                case 1:
                    RemoveFirst();
                    break;

                case 2:
                    RemoveMidLines(2);
                    break;

                case 3:
                    RemoveMidLines(3);
                    break;

                case 4:
                    RemoveLast();
                    break;
            }

            rowCounterLabel.Text = "Rows: " + (Settings.LineCounter - 1);
        }

        private void RemoveLast()
        {
            Label lb = (Label)this.Controls["id4Label"];
            if (Convert.ToInt32(lb.Text) == Settings.LineCounter)
            {
                if (Settings.LineCounter != 4)
                {
                    MoveList(1);
                }
                else
                {
                    ClearRow(4);
                }

                int ListIndex = (Settings.LineCounter - 1) * 3;
                int counter = 0;

                while (counter < 3)
                {
                    Settings.Lines.RemoveAt(ListIndex);
                    counter++;
                }
            }
            else
            {
                int ItemId = Convert.ToInt32(lb.Text);
                int ListId = ItemId * 3;

                lb = (Label)this.Controls["typeLabel4"];
                lb.Text = Settings.Lines[ListId + 1];
                if (lb.Text == "work")
                {
                    lb.ForeColor = Color.White;
                }
                else
                {
                    lb.ForeColor = Color.Red;
                }

                lb = (Label)this.Controls["time4Label"];
                lb.Text = Settings.Lines[ListId + 2];

                int counter = 0;
                while (counter < 3)
                {
                    Settings.Lines.RemoveAt(ListId - 3);
                    counter++;
                }

                int RowsFront = Settings.LineCounter - ItemId;

                for (int i = 0; i < RowsFront; i++)
                {
                    Settings.Lines[ListId - 3 + (i * 3)] = Convert.ToString(Convert.ToInt32(Settings.Lines[ListId - 3 + (i * 3)]) - 1);
                }
            }
        }

        private void SortList(int RowsFront, int LineID)
        {
            if (RowsFront == 0)
            {
                if (LineID == 1)
                {
                    Settings.Lines.Clear();
                }
                else
                {
                    int ListIndex = (LineID - 1) * 3;

                    int counter = 0;
                    while (counter != 3)
                    {
                        Settings.Lines.RemoveAt(ListIndex);
                        counter++;
                    }
                }
            }
            else
            {
                string Name = "id" + LineID + "Label";
                Label lb1 = (Label)this.Controls[Name];

                int listId = Convert.ToInt32(lb1.Text);
                listId = (listId - 1) * 3;

                int size = Settings.Lines.Count;
                int change = ((size - listId) / 3) - 1;
                int[] changeIds = new int[change];

                for (int i = 0; i < change; i++)
                {
                    changeIds[i] = listId + ((i + 1) * 3);
                    Settings.Lines[changeIds[i]] = Convert.ToString(Convert.ToInt32(Settings.Lines[changeIds[i]]) - 1);
                }

                int counter = 0;
                while (counter != 3)
                {
                    Settings.Lines.RemoveAt(listId);
                    counter++;
                }
            }
        }

        private void moveListUpPic_Click(object sender, EventArgs e)
        {
            if (Settings.LineCounter > 4)
            {
                Label lb = (Label)this.Controls["id1Label"];
                if (Convert.ToInt32(lb.Text) != 1)
                {
                    MoveList(1);
                }
            }
        }

        private void moveListDownPic_Click(object sender, EventArgs e)
        {
            if (Settings.LineCounter > 4)
            {
                Label lb = (Label)this.Controls["id4Label"];
                if (Convert.ToInt32(lb.Text) < Settings.LineCounter)
                {
                    MoveList(4);
                }
            }
        }

        private void MoveList(int ListID)
        {
            string name = "id" + ListID + "Label";
            Label lb = (Label)this.Controls[name];
            if (Settings.LineCounter >= 5)
            {
                if (ListID == 1)
                {
                    for (int i = 3; i > 0; i--)
                    {
                        name = "id" + i + "Label";
                        lb = (Label)this.Controls[name];
                        name = "id" + (i + 1) + "Label";
                        Label lb2 = (Label)this.Controls[name];
                        lb2.Text = lb.Text;

                        name = "typeLabel" + i;
                        lb = (Label)this.Controls[name];
                        name = "typeLabel" + (i + 1);
                        lb2 = (Label)this.Controls[name];
                        lb2.Text = lb.Text;
                        lb2.ForeColor = lb.ForeColor;

                        name = "time" + i + "Label";
                        lb = (Label)this.Controls[name];
                        name = "time" + (i + 1) + "Label";
                        lb2 = (Label)this.Controls[name];
                        lb2.Text = lb.Text;
                    }
                }
                else
                {
                    for (int i = 1; i < 4; i++)
                    {
                        name = "id" + i + "Label";
                        lb = (Label)this.Controls[name];
                        name = "id" + (i + 1) + "Label";
                        Label lb2 = (Label)this.Controls[name];
                        lb.Text = lb2.Text;

                        name = "typeLabel" + i;
                        lb = (Label)this.Controls[name];
                        name = "typeLabel" + (i + 1);
                        lb2 = (Label)this.Controls[name];
                        lb.Text = lb2.Text;
                        lb.ForeColor = lb2.ForeColor;

                        name = "time" + i + "Label";
                        lb = (Label)this.Controls[name];
                        name = "time" + (i + 1) + "Label";
                        lb2 = (Label)this.Controls[name];
                        lb.Text = lb2.Text;
                    }
                }

                name = "id" + ListID + "Label";
                lb = (Label)this.Controls[name];

                int ListIndex;

                if (ListID == 1)
                {
                    ListIndex = (Convert.ToInt32(lb.Text) - 2) * 3;
                }
                else
                {
                    ListIndex = ((Convert.ToInt32(lb.Text) - 1) * 3) + 3;
                }

                lb.Text = Settings.Lines[ListIndex];

                name = "typeLabel" + ListID;
                lb = (Label)this.Controls[name];
                lb.Text = Settings.Lines[ListIndex + 1];

                if (lb.Text == "work")
                {
                    lb.ForeColor = Color.White;
                }
                else
                {
                    lb.ForeColor = Color.Red;
                }

                name = "time" + ListID + "Label";
                lb = (Label)this.Controls[name];
                lb.Text = Settings.Lines[ListIndex + 2];
            }
        }

        private void LoadIntervall()
        {
            roundsLabel.Show();
            roundsTextBox.Show();
            plusRestButton.Show();
            plusWorkButton.Show();
            rowCounterLabel.Show();
            moveListDownPic.Show();
            moveListUpPic.Show();
            rowCounterLabel.Show();

            for (int i = 0; i < 4; i++)
            {
                if (Settings.LineCounter >= i + 1)
                {
                    string Name = "id" + (i + 1) + "Label";
                    Label lb = (Label)this.Controls[Name];
                    lb.Show();

                    Name = "typeLabel" + (i + 1);
                    lb = (Label)this.Controls[Name];
                    lb.Show();

                    Name = "time" + (i + 1) + "Label";
                    lb = (Label)this.Controls[Name];
                    lb.Show();

                    Name = "downArrow" + (i + 1);
                    PictureBox pb = (PictureBox)this.Controls[Name];
                    pb.Show();

                    Name = "upArrow" + (i + 1);
                    pb = (PictureBox)this.Controls[Name];
                    pb.Show();

                    Name = "duplicate" + (i + 1);
                    pb = (PictureBox)this.Controls[Name];
                    pb.Show();

                    Name = "remove" + (i + 1);
                    pb = (PictureBox)this.Controls[Name];
                    pb.Show();
                }
            }
        }

        private void LoadDefault()
        {
            Settings.InterVall = false;

            roundsLabel.Hide();
            roundsTextBox.Hide();
            plusRestButton.Hide();
            plusWorkButton.Hide();
            rowCounterLabel.Hide();
            addNewButton.Hide();
            addNewLabel.Hide();
            testMinTextBox.Hide();
            testSecTextBox.Hide();
            topLineLabel.Hide();
            bottomLineLabel.Hide();
            moveListDownPic.Hide();
            moveListUpPic.Hide();
            dotsLabel.Hide();
            cancelButton.Hide();

            id1Label.Hide(); id2Label.Hide(); id3Label.Hide(); id4Label.Hide();

            typeLabel1.Hide(); typeLabel2.Hide(); typeLabel3.Hide(); typeLabel4.Hide();

            time1Label.Hide(); time2Label.Hide(); time3Label.Hide(); time4Label.Hide();

            downArrow1.Hide(); downArrow2.Hide(); downArrow3.Hide(); downArrow4.Hide();

            upArrow1.Hide(); upArrow2.Hide(); upArrow3.Hide(); upArrow4.Hide();

            duplicate1.Hide(); duplicate2.Hide(); duplicate3.Hide(); duplicate4.Hide();

            remove1.Hide(); remove2.Hide(); remove3.Hide(); remove4.Hide();
        }

        private void testMinTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void testSecTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void downArrow1_Click(object sender, EventArgs e)
        {
            MoveSingleLine(false, 1);
        }

        private void downArrow2_Click(object sender, EventArgs e)
        {
            MoveSingleLine(false, 2);
        }

        private void downArrow3_Click(object sender, EventArgs e)
        {
            MoveSingleLine(false, 3);
        }

        private void downArrow4_Click(object sender, EventArgs e)
        {
            MoveSingleLine(false, 4);
        }

        private void MoveSingleLine(bool Up, int LineId)
        {
            if (Up)
            {
                switch (LineId)
                {
                    case 1:
                        if (id1Label.Text == "1")
                        {
                            MessageBox.Show("This is the first item!");
                        }
                        else if (Convert.ToInt32(id1Label.Text) == Settings.LineCounter)
                        {
                            MessageBox.Show("This is the last item!");
                        }
                        else
                        {
                            string Help;
                            int ListHelp = ((Convert.ToInt32(id1Label.Text) - 1) * 3) + 1;

                            Help = Settings.Lines[ListHelp];
                            Settings.Lines[ListHelp] = Settings.Lines[ListHelp - 3];
                            Settings.Lines[ListHelp - 3] = Help;

                            Help = Settings.Lines[ListHelp + 1];
                            Settings.Lines[ListHelp + 1] = Settings.Lines[(ListHelp + 1) - 3];
                            Settings.Lines[(ListHelp + 1) - 3] = Help;

                            typeLabel1.Text = Settings.Lines[ListHelp];

                            if (typeLabel1.Text == "work")
                            {
                                typeLabel1.ForeColor = Color.White;
                            }
                            else
                            {
                                typeLabel1.ForeColor = Color.Red;
                            }

                            time1Label.Text = Settings.Lines[ListHelp + 1];
                        }

                        break;

                    default:
                        string HelpString, name1;
                        int ListId;

                        name1 = "typeLabel" + LineId;
                        Label lb2 = (Label)this.Controls[name1];

                        name1 = "typeLabel" + (LineId - 1);
                        Label lb1 = (Label)this.Controls[name1];

                        HelpString = lb2.Text;
                        lb2.Text = lb1.Text;
                        lb1.Text = HelpString;

                        if (lb1.ForeColor != lb2.ForeColor)
                        {
                            if (lb1.ForeColor == Color.Red)
                            {
                                lb1.ForeColor = Color.White;
                                lb2.ForeColor = Color.Red;
                            }
                            else
                            {
                                lb2.ForeColor = Color.White;
                                lb1.ForeColor = Color.Red;
                            }
                        }

                        name1 = "time" + LineId + "Label";
                        lb1 = (Label)this.Controls[name1];

                        name1 = "time" + (LineId - 1) + "Label";
                        lb2 = (Label)this.Controls[name1];

                        HelpString = lb2.Text;
                        lb2.Text = lb1.Text;
                        lb1.Text = HelpString;

                        name1 = "id" + LineId + "Label";
                        lb1 = (Label)this.Controls[name1];
                        ListId = ((Convert.ToInt32(lb1.Text) - 1) * 3) + 1;

                        HelpString = Settings.Lines[ListId];
                        Settings.Lines[ListId] = Settings.Lines[ListId - 3];
                        Settings.Lines[ListId - 3] = HelpString;

                        HelpString = Settings.Lines[ListId + 1];
                        Settings.Lines[ListId + 1] = Settings.Lines[(ListId + 1) - 3];
                        Settings.Lines[(ListId + 1) - 3] = HelpString;

                        break;
                }
            }
            else
            {
                switch (LineId)
                {
                    case 4:
                        if (Convert.ToInt32(id4Label.Text) == Settings.LineCounter)
                        {
                            MessageBox.Show("This is the last item!");
                        }
                        else
                        {
                            string Help;
                            int ListHelp = ((Convert.ToInt32(id4Label.Text) - 1) * 3) + 1;

                            Help = Settings.Lines[ListHelp];
                            Settings.Lines[ListHelp] = Settings.Lines[ListHelp + 3];
                            Settings.Lines[ListHelp + 3] = Help;

                            Help = Settings.Lines[ListHelp + 1];
                            Settings.Lines[ListHelp + 1] = Settings.Lines[(ListHelp + 1) + 3];
                            Settings.Lines[(ListHelp + 1) + 3] = Help;

                            typeLabel4.Text = Settings.Lines[ListHelp];

                            if (typeLabel4.Text == "work")
                            {
                                typeLabel4.ForeColor = Color.White;
                            }
                            else
                            {
                                typeLabel4.ForeColor = Color.Red;
                            }

                            time4Label.Text = Settings.Lines[ListHelp + 1];
                        }

                        break;

                    default:
                        string HelpString, name1;
                        int ListId;

                        name1 = "id" + LineId + "Label";
                        Label lb1 = (Label)this.Controls[name1];
                        if (Settings.LineCounter == Convert.ToInt32(lb1.Text))
                        {
                            MessageBox.Show("This is the last item!");
                        }
                        else
                        {
                            name1 = "typeLabel" + LineId;
                            Label lb2 = (Label)this.Controls[name1];

                            name1 = "typeLabel" + (LineId + 1);
                            lb1 = (Label)this.Controls[name1];

                            HelpString = lb2.Text;
                            lb2.Text = lb1.Text;
                            lb1.Text = HelpString;

                            if (lb1.ForeColor != lb2.ForeColor)
                            {
                                if (lb1.ForeColor == Color.Red)
                                {
                                    lb1.ForeColor = Color.White;
                                    lb2.ForeColor = Color.Red;
                                }
                                else
                                {
                                    lb2.ForeColor = Color.White;
                                    lb1.ForeColor = Color.Red;
                                }
                            }

                            name1 = "time" + LineId + "Label";
                            lb1 = (Label)this.Controls[name1];

                            name1 = "time" + (LineId + 1) + "Label";
                            lb2 = (Label)this.Controls[name1];

                            HelpString = lb2.Text;
                            lb2.Text = lb1.Text;
                            lb1.Text = HelpString;

                            name1 = "id" + LineId + "Label";
                            lb1 = (Label)this.Controls[name1];

                            ListId = ((Convert.ToInt32(lb1.Text) - 1) * 3) + 1;

                            HelpString = Settings.Lines[ListId];
                            Settings.Lines[ListId] = Settings.Lines[ListId + 3];
                            Settings.Lines[ListId + 3] = HelpString;

                            HelpString = Settings.Lines[ListId + 1];
                            Settings.Lines[ListId + 1] = Settings.Lines[(ListId + 1) + 3];
                            Settings.Lines[(ListId + 1) + 3] = HelpString;
                        }
                        break;
                }
            }
        }

        private void upArrow1_Click(object sender, EventArgs e)
        {
            MoveSingleLine(true, 1);
        }

        private void upArrow2_Click(object sender, EventArgs e)
        {
            MoveSingleLine(true, 2);
        }

        private void upArrow3_Click(object sender, EventArgs e)
        {
            MoveSingleLine(true, 3);
        }

        private void upArrow4_Click(object sender, EventArgs e)
        {
            MoveSingleLine(true, 4);
        }

        private void addNewButton_Click(object sender, EventArgs e)
        {
            if ((Convert.ToInt32(testMinTextBox.Text) > 60 || Convert.ToInt32(testMinTextBox.Text) < 0) ||
                (Convert.ToInt32(testSecTextBox.Text) > 59 || Convert.ToInt32(testSecTextBox.Text) < 0))
            {
                MessageBox.Show("Wrong time data! Minutes can't have a negative value, seconds can't be bigger than 59!");
            }
            else if (Convert.ToInt32(testMinTextBox.Text) == 0 && Convert.ToInt32(testMinTextBox.Text) == 0)
            {
                MessageBox.Show("Can't add it with 0 length!");
            }
            else
            {
                FinishedAdding = true;
                switch (Settings.LineCounter)
                {
                    case 1:
                        id1Label.Text = Settings.LineCounter.ToString();
                        time1Label.Text = testMinTextBox.Text + ":" + testSecTextBox.Text;

                        if (IsWork)
                        {
                            typeLabel1.ForeColor = Color.White;
                            typeLabel1.Text = "work";
                        }
                        else
                        {
                            typeLabel1.ForeColor = Color.Red;
                            typeLabel1.Text = "rest";
                        }

                        id1Label.Show();
                        typeLabel1.Show();
                        time1Label.Show();
                        downArrow1.Show();
                        upArrow1.Show();
                        duplicate1.Show();
                        remove1.Show();

                        Settings.Lines.Add(id1Label.Text);
                        Settings.Lines.Add(typeLabel1.Text);
                        Settings.Lines.Add(time1Label.Text);

                        break;

                    case 2:
                        id2Label.Text = Settings.LineCounter.ToString();
                        time2Label.Text = testMinTextBox.Text + ":" + testSecTextBox.Text;

                        if (IsWork)
                        {
                            typeLabel2.ForeColor = Color.White;
                            typeLabel2.Text = "work";
                        }
                        else
                        {
                            typeLabel2.ForeColor = Color.Red;
                            typeLabel2.Text = "rest";
                        }

                        id2Label.Show();
                        typeLabel2.Show();
                        time2Label.Show();
                        downArrow2.Show();
                        upArrow2.Show();
                        duplicate2.Show();
                        remove2.Show();

                        Settings.Lines.Add(id2Label.Text);
                        Settings.Lines.Add(typeLabel2.Text);
                        Settings.Lines.Add(time2Label.Text);

                        break;

                    case 3:
                        id3Label.Text = Settings.LineCounter.ToString();
                        time3Label.Text = testMinTextBox.Text + ":" + testSecTextBox.Text;

                        if (IsWork)
                        {
                            typeLabel3.ForeColor = Color.White;
                            typeLabel3.Text = "work";
                        }
                        else
                        {
                            typeLabel3.ForeColor = Color.Red;
                            typeLabel3.Text = "rest";
                        }

                        id3Label.Show();
                        typeLabel3.Show();
                        time3Label.Show();
                        downArrow3.Show();
                        upArrow3.Show();
                        duplicate3.Show();
                        remove3.Show();

                        Settings.Lines.Add(id3Label.Text);
                        Settings.Lines.Add(typeLabel3.Text);
                        Settings.Lines.Add(time3Label.Text);

                        break;

                    case 4:
                        id4Label.Text = Settings.LineCounter.ToString();
                        time4Label.Text = testMinTextBox.Text + ":" + testSecTextBox.Text;

                        if (IsWork)
                        {
                            typeLabel4.ForeColor = Color.White;
                            typeLabel4.Text = "work";
                        }
                        else
                        {
                            typeLabel4.ForeColor = Color.Red;
                            typeLabel4.Text = "rest";
                        }

                        id4Label.Show();
                        typeLabel4.Show();
                        time4Label.Show();
                        downArrow4.Show();
                        upArrow4.Show();
                        duplicate4.Show();
                        remove4.Show();

                        Settings.Lines.Add(id4Label.Text);
                        Settings.Lines.Add(typeLabel4.Text);
                        Settings.Lines.Add(time4Label.Text);

                        break;

                    default:

                        Label lb = (Label)this.Controls["id4Label"];
                        if (Convert.ToInt32(lb.Text) == Settings.LineCounter - 1)
                        {
                            SortLines();

                            id4Label.Text = Settings.LineCounter.ToString();
                            time4Label.Text = testMinTextBox.Text + ":" + testSecTextBox.Text;

                            if (IsWork)
                            {
                                typeLabel4.ForeColor = Color.White;
                                typeLabel4.Text = "work";
                            }
                            else
                            {
                                typeLabel4.ForeColor = Color.Red;
                                typeLabel4.Text = "rest";
                            }

                            Settings.Lines.Add(id4Label.Text);
                            Settings.Lines.Add(typeLabel4.Text);
                            Settings.Lines.Add(time4Label.Text);
                        }
                        else
                        {
                            Settings.Lines.Add(Settings.LineCounter.ToString());

                            if (IsWork)
                            {
                                Settings.Lines.Add("work");
                            }
                            else
                            {
                                Settings.Lines.Add("rest");
                            }

                            Settings.Lines.Add(testMinTextBox.Text + ":" + testSecTextBox.Text);
                        }

                        break;
                }

                testMinTextBox.Hide();
                testSecTextBox.Hide();
                addNewLabel.Hide();
                addNewButton.Hide();
                dotsLabel.Hide();
                cancelButton.Hide();
                rowCounterLabel.Text = "Rows: " + Settings.LineCounter.ToString();
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            FinishedAdding = true;
            Settings.LineCounter--;
            testMinTextBox.Hide();
            testSecTextBox.Hide();
            dotsLabel.Hide();
            cancelButton.Hide();
            addNewButton.Hide();
            addNewLabel.Hide();
        }

        private void duplicate1_Click(object sender, EventArgs e)
        {
            DuplicateItem(1);
        }

        private void duplicate2_Click(object sender, EventArgs e)
        {
            DuplicateItem(2);
        }

        private void duplicate3_Click(object sender, EventArgs e)
        {
            DuplicateItem(3);
        }

        private void duplicate4_Click(object sender, EventArgs e)
        {
            DuplicateItem(4);
        }

        private void DuplicateItem(int LineId)
        {
            Settings.Lines.Add(Convert.ToString(Settings.LineCounter + 1));

            string name = "typeLabel" + LineId;
            Label lb = (Label)this.Controls[name];
            Settings.Lines.Add(lb.Text);

            name = "time" + LineId + "Label";
            lb = (Label)this.Controls[name];
            Settings.Lines.Add(lb.Text);

            if (Settings.LineCounter < 4)
            {
                switch (Settings.LineCounter)
                {
                    case 1:
                        id2Label.Text = Convert.ToString(Settings.LineCounter + 1); ;
                        typeLabel2.Text = Settings.Lines[Settings.Lines.Count - 5];
                        if (typeLabel2.Text == "work")
                        {
                            typeLabel2.ForeColor = Color.White;
                        }
                        else
                        {
                            typeLabel2.ForeColor = Color.Red;
                        }

                        time2Label.Text = Settings.Lines[Settings.Lines.Count - 4];

                        id2Label.Show();
                        typeLabel2.Show();
                        time2Label.Show();
                        downArrow2.Show();
                        upArrow2.Show();
                        duplicate2.Show();
                        remove2.Show();

                        Settings.LineCounter++;
                        rowCounterLabel.Text = "Rows: " + Settings.LineCounter;
                        break;

                    case 2:
                        id3Label.Text = Convert.ToString(Settings.LineCounter + 1);
                        typeLabel3.Text = Settings.Lines[Settings.Lines.Count - 2];
                        if (typeLabel3.Text == "work")
                        {
                            typeLabel3.ForeColor = Color.White;
                        }
                        else
                        {
                            typeLabel3.ForeColor = Color.Red;
                        }

                        time3Label.Text = Settings.Lines[Settings.Lines.Count - 1];

                        id3Label.Show();
                        typeLabel3.Show();
                        time3Label.Show();
                        downArrow3.Show();
                        upArrow3.Show();
                        duplicate3.Show();
                        remove3.Show();

                        Settings.LineCounter++;
                        rowCounterLabel.Text = "Rows: " + Settings.LineCounter;
                        break;

                    case 3:
                        id4Label.Text = Convert.ToString(Settings.LineCounter + 1);
                        typeLabel4.Text = Settings.Lines[Settings.Lines.Count - 2];
                        if (typeLabel4.Text == "work")
                        {
                            typeLabel4.ForeColor = Color.White;
                        }
                        else
                        {
                            typeLabel4.ForeColor = Color.Red;
                        }

                        time4Label.Text = Settings.Lines[Settings.Lines.Count - 1];

                        id4Label.Show();
                        typeLabel4.Show();
                        time4Label.Show();
                        downArrow4.Show();
                        upArrow4.Show();
                        duplicate4.Show();
                        remove4.Show();

                        Settings.LineCounter++;
                        rowCounterLabel.Text = "Rows: " + Settings.LineCounter;
                        break;
                }
            }
            else
            {
                Settings.LineCounter++;
                rowCounterLabel.Text = "Rows: " + Settings.LineCounter;
                MessageBox.Show("Duplicated line copied to the end of the list!");
            }
        }

        private void customHourTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void customMinutesTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void roundsTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void saveLabel_Click(object sender, EventArgs e)
        {
            if (saveNameTextBox.Text == "")
            {
                MessageBox.Show("Forget to add a name!");
            }
            else if (roundsTextBox.Text == "")
            {
                MessageBox.Show("Fill the Rounds text box!");
            }
            else if (customHourTextBox.Text == "" || customMinutesTextBox.Text == "")
            {
                MessageBox.Show("Fill the time text box!");
            }
            else
            {
                Settings.Lines.Add(roundsTextBox.Text);
                Settings.Lines.Add(customHourTextBox.Text);
                Settings.Lines.Add(customMinutesTextBox.Text);

                XDocument myDoc = new XDocument(
                    new XDeclaration("1.0", "utf-8", "yes"),
                    new XElement("CustomRound"));

                int ListStep = 0;

                for (int i = 0; i < Settings.LineCounter; i++)
                {
                    myDoc.Root.Add(new XElement("Round",
                        new XAttribute("id", Settings.Lines[ListStep]),
                        new XAttribute("type", Settings.Lines[ListStep + 1]),
                        new XAttribute("length", Settings.Lines[ListStep + 2])
                        ));

                    ListStep = ListStep + 3;
                }

                myDoc.Root.Add(new XAttribute("RoundsNumber", Settings.Lines[ListStep]));
                myDoc.Root.Add(new XAttribute("Min", Settings.Lines[ListStep]));
                myDoc.Root.Add(new XAttribute("Sec", Settings.Lines[ListStep]));

                myDoc.Save(@"C:\Users\z004ubyc.AD005\Desktop\" + saveNameTextBox.Text + ".xml");

                MessageBox.Show("Save File created!");
            }
        }
    }
}
